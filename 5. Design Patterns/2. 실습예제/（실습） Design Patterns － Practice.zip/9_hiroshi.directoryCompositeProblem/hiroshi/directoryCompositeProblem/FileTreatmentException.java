package hiroshi.directoryCompositeProblem;
public class FileTreatmentException extends RuntimeException {      
    public FileTreatmentException() {
    }
    public FileTreatmentException(String msg) {
        super(msg);
    }
}
