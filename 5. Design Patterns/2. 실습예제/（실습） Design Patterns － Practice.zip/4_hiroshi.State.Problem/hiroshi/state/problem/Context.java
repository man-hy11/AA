package hiroshi.state.problem;
public interface Context {

    public abstract void setClock(int hour);                // set Clock
    public abstract void changeState(State state);          // change State
    public abstract void callSecurityCenter(String msg);     // call SecurityCenter
    public abstract void recordLog(String msg);            // record Log
}
