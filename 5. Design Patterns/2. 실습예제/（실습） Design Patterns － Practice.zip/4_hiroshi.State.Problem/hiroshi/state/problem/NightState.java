package hiroshi.state.problem;
public class NightState implements State {
    private static NightState singleton = new NightState();
    private NightState() {                              // private constructor
    }
    public static State getInstance() {                 // get the only instance
        return singleton;
    }
    public void doClock(Context context, int hour) {    // set clock
        if (9 <= hour && hour < 17) {
            context.changeState(DayState.getInstance());
        }
    }
    public void doUse(Context context) {                // use the bank vault
        context.callSecurityCenter("emergency : use of bank vault (NightState)!");
    }
    public void doAlarm(Context context) {              // emergency alarm
        context.callSecurityCenter("emergency alarm (NightState)");
    }
    public void doPhone(Context context) {              // regular call
        context.recordLog("night call");
    }
    public String toString() {                          // to string
        return "[NightState]";
    }
}
