package hiroshi.state.problem;
public class DayState implements State {
    private static DayState singleton = new DayState();
    private DayState() {                               // private constructor
    }
    public static State getInstance() {                 // get the only instance
        return singleton;
    }
    public void doClock(Context context, int hour) {    // set clock
        if (hour < 9 || 17 <= hour) {
            context.changeState(NightState.getInstance());
        }
    }
    public void doUse(Context context) {                // use the bank vault
        context.recordLog("use the bank vault (DayState)");
    }
    public void doAlarm(Context context) {              // emergency alarm
        context.callSecurityCenter("emergency alarm (DayState)");
    }
    public void doPhone(Context context) {              // regular call
        context.callSecurityCenter("call (DayState)");
    }
    public String toString() {                          // to string
        return "[DayState]";
    }
}

