package hiroshi.state.problem;
public interface State {
    public abstract void doClock(Context context, int hour);     // set clock
    public abstract void doUse(Context context);                // do Use
    public abstract void doAlarm(Context context);              // do Alarm
    public abstract void doPhone(Context context);              // do Phone
}
