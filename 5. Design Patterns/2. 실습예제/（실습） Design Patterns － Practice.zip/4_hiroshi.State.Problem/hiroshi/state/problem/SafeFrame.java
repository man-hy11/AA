package hiroshi.state.problem;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Color;
import java.awt.Button;
import java.awt.TextField;
import java.awt.TextArea;
import java.awt.Panel;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SafeFrame extends Frame implements ActionListener, Context {
    private TextField textClock = new TextField(60);        // Current Time Display
    private TextArea textScreen = new TextArea(10, 60);    // Output in the security center
    private Button buttonUse = new Button("Use");   // Use Button
    private Button buttonAlarm = new Button("Alarm");    // Alarm Button
    private Button buttonPhone = new Button("Phone");  // Phone Button
    private Button buttonExit = new Button("Exit");        // Exit Button

    private State state = DayState.getInstance();           // Current State

    // constructor
    public SafeFrame(String title) {
        super(title);
        setBackground(Color.lightGray);
        setLayout(new BorderLayout());
        // Placing textClock
        add(textClock, BorderLayout.NORTH);
        textClock.setEditable(false);
        // Placing textScreen
        add(textScreen, BorderLayout.CENTER);
        textScreen.setEditable(false);
        // Save buttons to the panel
        Panel panel = new Panel();
        panel.add(buttonUse);
        panel.add(buttonAlarm);
        panel.add(buttonPhone);
        panel.add(buttonExit);
        // Placing panel 
        add(panel, BorderLayout.SOUTH);
        // display
        pack();
        show();
        // set listener
        buttonUse.addActionListener(this);
        buttonAlarm.addActionListener(this);
        buttonPhone.addActionListener(this);
        buttonExit.addActionListener(this);
    }
    // When the button is pressed, it comes here
    public void actionPerformed(ActionEvent e) {
        System.out.println(e.toString());
        if (e.getSource() == buttonUse) {           // Use button
            state.doUse(this);
        } else if (e.getSource() == buttonAlarm) {  // Alarm button
            state.doAlarm(this);
        } else if (e.getSource() == buttonPhone) {  // Phone button
            state.doPhone(this);
        } else if (e.getSource() == buttonExit) {   // Exit button
            System.exit(0);
        } else {
            System.out.println("?");
        }
    }
    // set clock
    public void setClock(int hour) {
        String clockstring = "Current Time ";
        if (hour < 10) {
            clockstring += "0" + hour + ":00";
        } else {
            clockstring += hour + ":00";
        }
        System.out.println(clockstring);
        textClock.setText(clockstring);
        state.doClock(this, hour);
    }
    // change State
    public void changeState(State state) {
        System.out.println("State has changed from " + this.state + " to " + state + ".");
        this.state = state;
    }
    // call SecurityCenter
    public void callSecurityCenter(String msg) {
        textScreen.append("call! " + msg + "\n");
    }
    // record Log
    public void recordLog(String msg) {
        textScreen.append("record ... " + msg + "\n");
    }
}
