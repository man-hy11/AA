package headfirst.decorator.io.skeleton;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class LowerCaseInputStream extends FilterInputStream {
	
	// Decorator pattern should call the constructor of superclass.
	public LowerCaseInputStream(InputStream inputStream) {		
		super(inputStream);
	}
	
	// calls the superclass method and perform additional tasks.
	@Override
	public int read() throws IOException {
		int c = super.read();
		return ((c == -1) ? c : Character.toLowerCase((char)c));
	}
	
	@Override
	public int read(byte[] b, int offset, int len) throws IOException {
		int result = super.read(b, offset, len);
		for (int i = offset; i < offset+result ; i++ )
			b[i] = (byte)Character.toLowerCase((char)b[i]);
		
		return result;
	}
}
